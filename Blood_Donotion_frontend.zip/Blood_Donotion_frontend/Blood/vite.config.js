import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [
    tailwindcss(),
    react(),
  ],
  server: {
    proxy: {
      "/api": {
        target: "https://localhost:7045",
        changeOrigin: true,
        secure: false,
      },
    },
  },
});